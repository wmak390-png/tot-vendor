import { useState } from "react";
import {
  ArrowUpRight,
  BarChart3,
  Bell,
  Check,
  ChevronDown,
  ClipboardList,
  Clock3,
  Home,
  LayoutGrid,
  MapPin,
  MenuSquare,
  PackageCheck,
  Pause,
  ReceiptText,
  Settings2,
  UserRound,
  X,
  Zap,
} from "lucide-react";

type QuickAction = {
  label: string;
  detail: string;
  icon: typeof MenuSquare;
  tone: "orange" | "cream" | "ink";
};

const quickActions: QuickAction[] = [
  { label: "Edit menu", detail: "18 items live", icon: MenuSquare, tone: "orange" },
  { label: "View orders", detail: "3 need attention", icon: ClipboardList, tone: "cream" },
  { label: "Sales report", detail: "Today · $684.20", icon: BarChart3, tone: "ink" },
  { label: "Store settings", detail: "Hours & pickup", icon: Settings2, tone: "cream" },
];

export function Store() {
  const [isOpen, setIsOpen] = useState(true);
  const [acceptsOrders, setAcceptsOrders] = useState(true);
  const [onBreak, setOnBreak] = useState(false);
  const [showStorePicker, setShowStorePicker] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [activeAction, setActiveAction] = useState<string | null>(null);

  const handleStoreToggle = () => {
    setIsOpen((current) => {
      const next = !current;
      if (!next) {
        setAcceptsOrders(false);
        setOnBreak(false);
      }
      return next;
    });
  };

  const handleBreakToggle = () => {
    setOnBreak((current) => {
      const next = !current;
      setAcceptsOrders(!next);
      return next;
    });
  };

  const triggerAction = (label: string) => {
    setActiveAction(label);
    window.setTimeout(() => setActiveAction(null), 2200);
  };

  return (
    <main className="min-h-[100dvh] w-full bg-[#e9dfd1] px-0 text-[#30231e] sm:px-5 sm:py-5">
      <div className="relative mx-auto flex min-h-[100dvh] w-full max-w-[430px] flex-col overflow-hidden bg-[#f7f0e7] shadow-[0_20px_80px_rgba(53,35,24,0.15)] sm:min-h-[844px] sm:rounded-[30px]">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-48 bg-[radial-gradient(circle_at_78%_8%,rgba(255,151,61,0.24),transparent_44%),linear-gradient(180deg,rgba(255,247,235,0.72),transparent)]" />

        <header className="relative flex items-center justify-between px-5 pb-4 pt-5">
          <button
            type="button"
            onClick={() => setShowStorePicker((current) => !current)}
            className="group flex items-center gap-3 rounded-2xl text-left transition-transform active:scale-[0.98]"
            aria-expanded={showStorePicker}
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-[15px] bg-[#30231e] text-[17px] font-black tracking-[-0.08em] text-[#ff9a3d] shadow-[0_7px_16px_rgba(48,35,30,0.18)]">
              to
            </span>
            <span className="flex flex-col gap-0.5">
              <span className="text-[10px] font-bold uppercase tracking-[0.17em] text-[#987b67]">Your store</span>
              <span className="flex items-center gap-1 text-[15px] font-extrabold tracking-[-0.02em] text-[#30231e]">
                Little Fern Kitchen
                <ChevronDown className={`h-4 w-4 text-[#a98871] transition-transform ${showStorePicker ? "rotate-180" : ""}`} strokeWidth={2.4} />
              </span>
            </span>
          </button>

          <button
            type="button"
            onClick={() => setShowNotifications((current) => !current)}
            className="relative flex h-10 w-10 items-center justify-center rounded-full border border-[#dfd0c1] bg-[#fdf8f2] text-[#49352c] transition-colors hover:border-[#ff9a3d] hover:text-[#e4661d] active:scale-95"
            aria-label="View notifications"
          >
            <Bell className="h-[18px] w-[18px]" strokeWidth={2.1} />
            <span className="absolute right-[8px] top-[7px] h-1.5 w-1.5 rounded-full bg-[#e4661d] ring-2 ring-[#fdf8f2]" />
          </button>

          {showStorePicker && (
            <div className="absolute left-5 right-5 top-[72px] z-20 rounded-2xl border border-[#eadbcb] bg-[#fffaf5] p-2 shadow-[0_18px_36px_rgba(65,42,26,0.18)]">
              <div className="flex items-center gap-3 rounded-xl bg-[#fff0e1] px-3 py-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#ff9a3d] text-[11px] font-black text-[#30231e]">LF</div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-bold text-[#30231e]">Little Fern Kitchen</p>
                  <p className="text-[10px] text-[#987b67]">Main Street · Open now</p>
                </div>
                <Check className="h-4 w-4 text-[#e4661d]" strokeWidth={2.7} />
              </div>
              <button
                type="button"
                onClick={() => setShowStorePicker(false)}
                className="mt-1 flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-xs font-semibold text-[#987b67] transition-colors hover:bg-[#f5eadf]"
              >
                <PlusStoreIcon />
                Add another store
              </button>
            </div>
          )}

          {showNotifications && (
            <div className="absolute right-5 top-[72px] z-20 w-[260px] rounded-2xl border border-[#eadbcb] bg-[#fffaf5] p-3 shadow-[0_18px_36px_rgba(65,42,26,0.18)]">
              <div className="mb-2 flex items-center justify-between">
                <p className="text-xs font-extrabold text-[#30231e]">Updates</p>
                <button type="button" onClick={() => setShowNotifications(false)} aria-label="Close updates">
                  <X className="h-4 w-4 text-[#a98871]" />
                </button>
              </div>
              <p className="rounded-xl bg-[#f8eee4] px-3 py-2 text-[11px] leading-4 text-[#674f40]">
                Lunch rush is moving quickly. You have 3 orders to prep.
              </p>
            </div>
          )}
        </header>

        <section className="relative px-5">
          <div className="rounded-[25px] bg-[#30231e] p-5 text-[#fff8ef] shadow-[0_14px_28px_rgba(48,35,30,0.17)]">
            <div className="mb-5 flex items-start justify-between">
              <div>
                <p className="mb-1 flex items-center gap-1.5 text-[11px] font-semibold tracking-[0.01em] text-[#d8bca5]">
                  <MapPin className="h-3.5 w-3.5 text-[#ff9a3d]" strokeWidth={2.4} />
                  122 Main Street · Portland
                </p>
                <h1 className="text-[26px] font-black leading-8 tracking-[-0.055em]">Good morning, Maya.</h1>
              </div>
              <span className="rounded-full bg-[#4a352a] px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.13em] text-[#ffb16b]">Tue, Jun 18</span>
            </div>

            <div className="flex items-center justify-between border-t border-[#554139] pt-4">
              <div className="flex items-center gap-2.5">
                <span className={`relative flex h-9 w-9 items-center justify-center rounded-full ${isOpen ? "bg-[#ff9a3d] text-[#30231e]" : "bg-[#5b4940] text-[#d8bca5]"}`}>
                  {isOpen ? <Zap className="h-[17px] w-[17px] fill-current" strokeWidth={2.2} /> : <Pause className="h-[17px] w-[17px]" strokeWidth={2.2} />}
                </span>
                <span>
                  <span className="block text-[13px] font-extrabold">{isOpen ? "Store is open" : "Store is closed"}</span>
                  <span className="mt-0.5 block text-[10px] text-[#c5a995]">{isOpen ? "Taking orders until 3:30 PM" : "Customers can’t place orders"}</span>
                </span>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={isOpen}
                onClick={handleStoreToggle}
                className={`relative h-7 w-[49px] rounded-full p-1 transition-colors duration-200 ${isOpen ? "bg-[#ff9a3d]" : "bg-[#624b3e]"}`}
              >
                <span className={`block h-5 w-5 rounded-full bg-[#fff7ed] shadow-sm transition-transform duration-200 ${isOpen ? "translate-x-[21px]" : "translate-x-0"}`} />
              </button>
            </div>
          </div>
        </section>

        <section className="relative px-5 pt-4">
          <div className="mb-2.5 flex items-end justify-between px-0.5">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-[0.17em] text-[#a27f67]">Right now</p>
              <h2 className="mt-0.5 text-[18px] font-black tracking-[-0.04em] text-[#30231e]">Rush controls</h2>
            </div>
            <span className="flex items-center gap-1 text-[10px] font-bold text-[#8b6f5c]">
              <Clock3 className="h-3.5 w-3.5" strokeWidth={2.1} />
              Updated just now
            </span>
          </div>

          <div className="overflow-hidden rounded-[21px] border border-[#e7d9cc] bg-[#fffaf5]">
            <button
              type="button"
              onClick={() => setAcceptsOrders((current) => !current)}
              disabled={!isOpen || onBreak}
              className="flex w-full items-center gap-3.5 px-4 py-3.5 text-left transition-colors hover:bg-[#fff5ec] active:bg-[#f9ebdd] disabled:cursor-not-allowed disabled:opacity-55"
            >
              <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${acceptsOrders && isOpen && !onBreak ? "bg-[#fff0e0] text-[#e4661d]" : "bg-[#f1e7dd] text-[#9b806d]"}`}>
                <PackageCheck className="h-[18px] w-[18px]" strokeWidth={2.1} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[13px] font-extrabold text-[#3b2921]">Accepting orders</span>
                <span className="mt-0.5 block text-[10px] text-[#9a7d68]">{acceptsOrders && isOpen && !onBreak ? "Orders are flowing in" : "Orders are paused"}</span>
              </span>
              <span className={`flex h-6 w-6 items-center justify-center rounded-full ${acceptsOrders && isOpen && !onBreak ? "bg-[#e4661d] text-[#fffaf5]" : "bg-[#ded0c2] text-[#937865]"}`}>
                <Check className="h-3.5 w-3.5" strokeWidth={3} />
              </span>
            </button>
            <div className="mx-4 border-t border-[#eee2d7]" />
            <button
              type="button"
              onClick={handleBreakToggle}
              disabled={!isOpen}
              className="flex w-full items-center gap-3.5 px-4 py-3.5 text-left transition-colors hover:bg-[#fff5ec] active:bg-[#f9ebdd] disabled:cursor-not-allowed disabled:opacity-55"
            >
              <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${onBreak ? "bg-[#fff0e0] text-[#e4661d]" : "bg-[#f1e7dd] text-[#9b806d]"}`}>
                <Pause className="h-[18px] w-[18px]" strokeWidth={2.1} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[13px] font-extrabold text-[#3b2921]">Take a temporary break</span>
                <span className="mt-0.5 block text-[10px] text-[#9a7d68]">{onBreak ? "Orders paused · Tap to resume" : "Pause for 15 minutes"}</span>
              </span>
              <span className={`h-6 w-6 rounded-full border-2 ${onBreak ? "border-[#e4661d] bg-[#e4661d]" : "border-[#d7c6b6] bg-transparent"}`}>
                {onBreak && <Check className="h-full w-full p-1 text-[#fffaf5]" strokeWidth={3} />}
              </span>
            </button>
          </div>
        </section>

        <section className="relative px-5 pb-5 pt-5">
          <div className="mb-2.5 flex items-center justify-between px-0.5">
            <h2 className="text-[18px] font-black tracking-[-0.04em] text-[#30231e]">Quick actions</h2>
            <button
              type="button"
              onClick={() => triggerAction("All tools")}
              className="flex items-center gap-1 text-[11px] font-bold text-[#d9631c] transition-colors hover:text-[#a94811]"
            >
              All tools <ArrowUpRight className="h-3.5 w-3.5" strokeWidth={2.4} />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            {quickActions.map(({ label, detail, icon: Icon, tone }) => (
              <button
                type="button"
                key={label}
                onClick={() => triggerAction(label)}
                className={`group relative min-h-[105px] overflow-hidden rounded-[20px] border p-3.5 text-left transition-all hover:-translate-y-0.5 hover:shadow-[0_10px_18px_rgba(75,48,31,0.1)] active:translate-y-0 active:scale-[0.98] ${
                  tone === "orange"
                    ? "border-[#ef8e43] bg-[#ff9a3d] text-[#30231e]"
                    : tone === "ink"
                      ? "border-[#46342c] bg-[#46342c] text-[#fff8ef]"
                      : "border-[#e6d8ca] bg-[#fffaf5] text-[#30231e]"
                }`}
              >
                <span className={`mb-3 flex h-8 w-8 items-center justify-center rounded-xl ${tone === "orange" ? "bg-[#ffbf80]" : tone === "ink" ? "bg-[#62483a]" : "bg-[#f5e8dc]"}`}>
                  <Icon className={`h-[16px] w-[16px] ${tone === "orange" ? "text-[#814115]" : tone === "ink" ? "text-[#ffb16b]" : "text-[#df6a20]"}`} strokeWidth={2.2} />
                </span>
                <span className="block text-[12px] font-extrabold">{label}</span>
                <span className={`mt-0.5 block text-[10px] ${tone === "ink" ? "text-[#d2b9a7]" : tone === "orange" ? "text-[#814115]" : "text-[#9a7d68]"}`}>{detail}</span>
                <ArrowUpRight className={`absolute bottom-3 right-3 h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 ${tone === "ink" ? "text-[#d2b9a7]" : tone === "orange" ? "text-[#814115]" : "text-[#b89478]"}`} strokeWidth={2.2} />
              </button>
            ))}
          </div>
        </section>

        <div className="mt-auto border-t border-[#e9dbce] bg-[#fbf5ee]/95 px-3 pb-[max(13px,env(safe-area-inset-bottom))] pt-2.5 backdrop-blur">
          <nav className="flex items-center justify-around" aria-label="Main navigation">
            <NavItem icon={Home} label="Home" active />
            <NavItem icon={ReceiptText} label="Orders" badge="3" onClick={() => triggerAction("Orders")} />
            <NavItem icon={LayoutGrid} label="Menu" onClick={() => triggerAction("Menu")} />
            <NavItem icon={BarChart3} label="Insights" onClick={() => triggerAction("Insights")} />
            <NavItem icon={UserRound} label="Account" onClick={() => triggerAction("Account")} />
          </nav>
        </div>

        {activeAction && (
          <div className="absolute bottom-[78px] left-1/2 z-30 flex -translate-x-1/2 items-center gap-2 rounded-full bg-[#30231e] px-4 py-2.5 text-[11px] font-bold text-[#fff8ef] shadow-[0_10px_25px_rgba(48,35,30,0.24)]">
            <Check className="h-3.5 w-3.5 text-[#ff9a3d]" strokeWidth={3} />
            {activeAction} selected
          </div>
        )}
      </div>
    </main>
  );
}

function NavItem({
  icon: Icon,
  label,
  active = false,
  badge,
  onClick,
}: {
  icon: typeof Home;
  label: string;
  active?: boolean;
  badge?: string;
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`relative flex min-w-[56px] flex-col items-center gap-1 rounded-xl px-2 py-1.5 transition-colors active:scale-95 ${active ? "text-[#e4661d]" : "text-[#a28876] hover:text-[#604535]"}`}
    >
      <span className="relative">
        <Icon className="h-[18px] w-[18px]" strokeWidth={active ? 2.5 : 2.05} />
        {badge && <span className="absolute -right-2.5 -top-2 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#e4661d] px-1 text-[9px] font-black leading-none text-[#fff8ef]">{badge}</span>}
      </span>
      <span className="text-[9px] font-bold tracking-[0.01em]">{label}</span>
      {active && <span className="absolute -bottom-2 h-1 w-1 rounded-full bg-[#e4661d]" />}
    </button>
  );
}

function PlusStoreIcon() {
  return (
    <span className="flex h-4 w-4 items-center justify-center rounded-md border border-[#cdb7a5] text-[12px] leading-none text-[#8f715d]">
      +
    </span>
  );
}
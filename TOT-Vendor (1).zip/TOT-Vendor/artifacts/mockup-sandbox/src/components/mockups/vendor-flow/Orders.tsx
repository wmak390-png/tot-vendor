import { useMemo, useState } from "react";
import {
  Check,
  Clock3,
  Ellipsis,
  LockKeyhole,
  Plus,
  Radio,
  RotateCw,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";

type OrderStatus = "new" | "in-progress" | "ready";
type Filter = "all" | OrderStatus;

type Order = {
  id: string;
  customer: string;
  initials: string;
  pickup: string;
  pickupRange: string;
  items: { name: string; detail?: string; quantity: number }[];
  amount: string;
  status: OrderStatus;
  note?: string;
  urgent?: boolean;
};

const startingOrders: Order[] = [
  {
    id: "4821",
    customer: "Maya Rodriguez",
    initials: "MR",
    pickup: "12:35 PM",
    pickupRange: "12:35–12:45",
    items: [
      { name: "Citrus chicken bowl", detail: "extra herb sauce", quantity: 2 },
      { name: "Sesame greens", quantity: 1 },
    ],
    amount: "$38.50",
    status: "new",
    note: "Please keep the sauce on the side",
    urgent: true,
  },
  {
    id: "4818",
    customer: "Lewis Turner",
    initials: "LT",
    pickup: "12:25 PM",
    pickupRange: "12:25–12:35",
    items: [
      { name: "Harissa steak wrap", quantity: 1 },
      { name: "Roasted potato salad", quantity: 1 },
      { name: "Sparkling water", quantity: 2 },
    ],
    amount: "$24.80",
    status: "in-progress",
  },
  {
    id: "4814",
    customer: "Nia Bennett",
    initials: "NB",
    pickup: "12:15 PM",
    pickupRange: "12:15–12:25",
    items: [
      { name: "Miso salmon box", quantity: 1 },
      { name: "Ginger lemonade", quantity: 1 },
    ],
    amount: "$19.20",
    status: "ready",
  },
  {
    id: "4809",
    customer: "Theo Martin",
    initials: "TM",
    pickup: "12:50 PM",
    pickupRange: "12:50–1:00",
    items: [
      { name: "Market grain bowl", quantity: 1 },
      { name: "Chocolate tahini cookie", quantity: 2 },
    ],
    amount: "$22.40",
    status: "new",
  },
];

const statusLabels: Record<OrderStatus, string> = {
  new: "New",
  "in-progress": "In progress",
  ready: "Ready",
};

const statusColors: Record<OrderStatus, string> = {
  new: "bg-[#fff0df] text-[#bd4c13]",
  "in-progress": "bg-[#e8f0e9] text-[#39735a]",
  ready: "bg-[#e2edf0] text-[#346a70]",
};

function StatusIcon({ status }: { status: OrderStatus }) {
  if (status === "new") return <Plus aria-hidden="true" className="h-3.5 w-3.5" strokeWidth={2.5} />;
  if (status === "ready") return <Check aria-hidden="true" className="h-3.5 w-3.5" strokeWidth={2.5} />;
  return <RotateCw aria-hidden="true" className="h-3.5 w-3.5" strokeWidth={2.5} />;
}

function NextAction({ order, onAdvance }: { order: Order; onAdvance: () => void }) {
  const copy = order.status === "new" ? "Start prepping" : order.status === "in-progress" ? "Mark ready" : "Handed off";
  return (
    <button
      type="button"
      onClick={onAdvance}
      className={`flex min-h-11 flex-1 items-center justify-center gap-2 rounded-[0.7rem] px-4 text-[0.82rem] font-bold tracking-[-0.01em] transition-transform active:scale-[0.98] ${
        order.status === "ready"
          ? "border border-[#bfd0d0] bg-[#f5f8f6] text-[#35666a]"
          : "bg-[#202522] text-[#fff9f0] shadow-[0_3px_0_#121614]"
      }`}
    >
      {order.status === "ready" ? <Check aria-hidden="true" className="h-4 w-4" /> : <Clock3 aria-hidden="true" className="h-4 w-4" />}
      {copy}
    </button>
  );
}

function OrderCard({ order, onAdvance }: { order: Order; onAdvance: () => void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [noteVisible, setNoteVisible] = useState(Boolean(order.note));

  return (
    <article
      className={`relative overflow-hidden rounded-[1.15rem] border bg-[#fffaf3] shadow-[0_5px_16px_rgba(83,54,30,0.055)] transition-transform duration-200 ${
        order.urgent ? "border-[#eb8a4e] shadow-[0_6px_20px_rgba(224,102,43,0.13)]" : "border-[#eadcca]"
      }`}
    >
      {order.urgent && <div className="absolute inset-x-0 top-0 h-1 bg-[#ed6c2d]" />}
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 items-center gap-3">
            <div
              className={`grid h-10 w-10 shrink-0 place-items-center rounded-full text-[0.72rem] font-extrabold tracking-[0.03em] ${
                order.urgent ? "bg-[#f9d6ba] text-[#9b4014]" : "bg-[#f0e1cf] text-[#76553c]"
              }`}
            >
              {order.initials}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="truncate text-[0.98rem] font-extrabold tracking-[-0.025em] text-[#252822]">{order.customer}</h2>
                {order.urgent && (
                  <span className="shrink-0 rounded-full bg-[#ed6c2d] px-2 py-0.5 text-[0.58rem] font-extrabold uppercase tracking-[0.08em] text-[#fff8ef]">
                    Due soon
                  </span>
                )}
              </div>
              <p className="mt-0.5 font-mono text-[0.68rem] font-bold tracking-[0.04em] text-[#927f6d]">ORDER #{order.id}</p>
            </div>
          </div>
          <div className="relative">
            <button
              type="button"
              onClick={() => setMenuOpen((current) => !current)}
              aria-label={`More options for order ${order.id}`}
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[#927f6d] transition-colors hover:bg-[#f4e8da] active:bg-[#eedbc7]"
            >
              <Ellipsis aria-hidden="true" className="h-5 w-5" />
            </button>
            {menuOpen && (
              <div className="absolute right-0 top-10 z-10 w-32 rounded-xl border border-[#eadcca] bg-[#fffaf3] p-1.5 text-[0.72rem] font-bold text-[#4c4b42] shadow-[0_10px_24px_rgba(60,45,30,0.14)]">
                <button type="button" onClick={() => setNoteVisible((current) => !current)} className="w-full rounded-lg px-2.5 py-2 text-left hover:bg-[#f5e9dc]">
                  {noteVisible ? "Hide note" : "View note"}
                </button>
                <button type="button" onClick={() => setMenuOpen(false)} className="w-full rounded-lg px-2.5 py-2 text-left hover:bg-[#f5e9dc]">
                  Close menu
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between rounded-[0.75rem] bg-[#f7ecdf] px-3 py-2.5">
          <div className="flex items-center gap-2">
            <Clock3 aria-hidden="true" className={`h-4 w-4 ${order.urgent ? "text-[#d65a20]" : "text-[#8e715a]"}`} />
            <span className={`text-[0.75rem] font-bold ${order.urgent ? "text-[#ad4717]" : "text-[#675f54]"}`}>
              Pickup {order.pickupRange}
            </span>
          </div>
          <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[0.66rem] font-extrabold ${statusColors[order.status]}`}>
            <StatusIcon status={order.status} />
            {statusLabels[order.status]}
          </span>
        </div>

        <div className="mt-4 space-y-2">
          {order.items.map((item) => (
            <div key={`${order.id}-${item.name}`} className="flex items-start justify-between gap-3 text-[0.8rem]">
              <div className="flex min-w-0 gap-2.5">
                <span className="grid h-5 min-w-5 place-items-center rounded bg-[#f0e1cf] px-1 text-[0.65rem] font-extrabold text-[#6f573f]">{item.quantity}</span>
                <div className="min-w-0">
                  <p className="truncate font-semibold text-[#34362f]">{item.name}</p>
                  {item.detail && <p className="mt-0.5 text-[0.68rem] font-medium text-[#a08065]">{item.detail}</p>}
                </div>
              </div>
            </div>
          ))}
        </div>

        {noteVisible && order.note && (
          <div className="mt-3 flex items-start gap-2 border-l-2 border-[#e99a67] pl-2.5 text-[0.7rem] leading-relaxed text-[#876a53]">
            <span className="font-bold text-[#b7561c]">Note</span>
            <span>{order.note}</span>
          </div>
        )}

        <div className="mt-4 flex items-center gap-3 border-t border-[#efe3d5] pt-3.5">
          <span className="mr-auto text-[0.95rem] font-extrabold tracking-[-0.02em] text-[#292b26]">{order.amount}</span>
          <NextAction order={order} onAdvance={onAdvance} />
        </div>
      </div>
    </article>
  );
}

export function Orders() {
  const [orders, setOrders] = useState(startingOrders);
  const [filter, setFilter] = useState<Filter>("all");
  const [soundOn, setSoundOn] = useState(true);
  const [showSettings, setShowSettings] = useState(false);

  const visibleOrders = useMemo(() => {
    if (filter === "all") return orders;
    return orders.filter((order) => order.status === filter);
  }, [filter, orders]);

  const counts = useMemo(
    () => ({
      new: orders.filter((order) => order.status === "new").length,
      "in-progress": orders.filter((order) => order.status === "in-progress").length,
      ready: orders.filter((order) => order.status === "ready").length,
    }),
    [orders],
  );

  const advanceOrder = (orderId: string) => {
    setOrders((current) =>
      current.map((order) => {
        if (order.id !== orderId) return order;
        if (order.status === "new") return { ...order, status: "in-progress" };
        if (order.status === "in-progress") return { ...order, status: "ready" };
        return order;
      }),
    );
  };

  const filterOptions: { value: Filter; label: string; count?: number }[] = [
    { value: "all", label: "All orders", count: orders.length },
    { value: "new", label: "New", count: counts.new },
    { value: "in-progress", label: "In progress", count: counts["in-progress"] },
    { value: "ready", label: "Ready", count: counts.ready },
  ];

  return (
    <main className="min-h-[100dvh] w-full overflow-x-hidden bg-[#f8efe4] font-sans text-[#252822]">
      <header className="relative overflow-hidden bg-[#202522] px-5 pb-5 pt-5 text-[#fff8ee]">
        <div className="pointer-events-none absolute -right-16 -top-20 h-52 w-52 rounded-full border-[22px] border-[#e96b2d]/[0.13]" />
        <div className="pointer-events-none absolute -right-2 top-10 h-28 w-28 rounded-full border-[12px] border-[#f29351]/[0.1]" />
        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-[0.7rem] bg-[#ed6c2d] shadow-[0_3px_0_#a7471e]">
              <span className="font-serif text-[1.4rem] font-black leading-none text-[#fff7ed]">t</span>
            </div>
            <div>
              <p className="font-mono text-[0.58rem] font-bold uppercase tracking-[0.18em] text-[#e4aa84]">TakeOnTime</p>
              <p className="mt-0.5 text-[0.82rem] font-bold text-[#fff8ee]">Kitchen queue</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setSoundOn((current) => !current)}
              aria-label={soundOn ? "Mute order alerts" : "Turn on order alerts"}
              className="grid h-10 w-10 place-items-center rounded-full text-[#dac7b5] transition-colors hover:bg-[#343934] active:bg-[#424740]"
            >
              {soundOn ? <Volume2 aria-hidden="true" className="h-[18px] w-[18px]" /> : <VolumeX aria-hidden="true" className="h-[18px] w-[18px]" />}
            </button>
            <button
              type="button"
              onClick={() => setShowSettings((current) => !current)}
              aria-label="Open queue settings"
              className="grid h-10 w-10 place-items-center rounded-full text-[#dac7b5] transition-colors hover:bg-[#343934] active:bg-[#424740]"
            >
              {showSettings ? <X aria-hidden="true" className="h-[18px] w-[18px]" /> : <Ellipsis aria-hidden="true" className="h-[18px] w-[18px]" />}
            </button>
          </div>
        </div>

        {showSettings && (
          <div className="relative mt-3 flex items-center justify-between rounded-xl border border-[#4a4c44] bg-[#2b302c] px-3 py-2.5 text-[0.7rem] text-[#e8d8c9]">
            <span>Alerts are {soundOn ? "on" : "off"} for this device</span>
            <button type="button" onClick={() => setShowSettings(false)} className="font-bold text-[#f39a5d]">Done</button>
          </div>
        )}

        <div className="relative mt-6 flex items-end justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Radio aria-hidden="true" className="h-4 w-4 text-[#f28b4b]" />
              <span className="text-[0.68rem] font-extrabold uppercase tracking-[0.17em] text-[#f28b4b]">Live queue</span>
            </div>
            <h1 className="mt-2 font-serif text-[2.15rem] font-bold leading-[0.98] tracking-[-0.045em]">Good afternoon,<br />the line is moving.</h1>
          </div>
          <div className="mb-1 flex items-center gap-1.5 rounded-full bg-[#313732] px-2.5 py-1.5 text-[0.61rem] font-bold text-[#b7c5b9]">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#83c69f] opacity-50" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-[#75bc91]" />
            </span>
            Live
          </div>
        </div>
      </header>

      <section className="relative z-[1] -mt-1 px-4">
        <div className="grid grid-cols-3 gap-2.5 rounded-[1.1rem] border border-[#ead9c6] bg-[#fffaf3] p-2.5 shadow-[0_7px_20px_rgba(79,53,31,0.08)]">
          <div className="rounded-[0.8rem] bg-[#fff0df] px-2.5 py-3">
            <p className="text-[0.59rem] font-extrabold uppercase tracking-[0.1em] text-[#b96636]">New</p>
            <p className="mt-1 font-mono text-[1.35rem] font-bold tracking-[-0.08em] text-[#a94b19]">{counts.new}</p>
          </div>
          <div className="rounded-[0.8rem] bg-[#edf3ed] px-2.5 py-3">
            <p className="text-[0.59rem] font-extrabold uppercase tracking-[0.06em] text-[#62806c]">Cooking</p>
            <p className="mt-1 font-mono text-[1.35rem] font-bold tracking-[-0.08em] text-[#39735a]">{counts["in-progress"]}</p>
          </div>
          <div className="rounded-[0.8rem] bg-[#eaf1f1] px-2.5 py-3">
            <p className="text-[0.59rem] font-extrabold uppercase tracking-[0.08em] text-[#668285]">Ready</p>
            <p className="mt-1 font-mono text-[1.35rem] font-bold tracking-[-0.08em] text-[#346a70]">{counts.ready}</p>
          </div>
        </div>
      </section>

      <section className="px-4 pb-8 pt-5">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <p className="font-mono text-[0.6rem] font-bold uppercase tracking-[0.14em] text-[#a2846a]">Tuesday, 14 May</p>
            <h2 className="mt-1 text-[1.2rem] font-extrabold tracking-[-0.04em] text-[#292b26]">Pickup orders</h2>
          </div>
          <div className="flex items-center gap-1.5 text-[0.67rem] font-semibold text-[#957d68]">
            <Clock3 aria-hidden="true" className="h-3.5 w-3.5" />
            12:27 PM
          </div>
        </div>

        <div className="-mx-4 mb-5 flex gap-2 overflow-x-auto px-4 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {filterOptions.map((option) => {
            const selected = filter === option.value;
            return (
              <button
                key={option.value}
                type="button"
                onClick={() => setFilter(option.value)}
                className={`flex h-9 shrink-0 items-center gap-1.5 rounded-full border px-3.5 text-[0.72rem] font-bold transition-transform active:scale-[0.97] ${
                  selected ? "border-[#ed6c2d] bg-[#ed6c2d] text-[#fff9f0] shadow-[0_3px_0_#b85120]" : "border-[#e6d6c4] bg-[#fffaf3] text-[#76695b]"
                }`}
              >
                {option.label}
                <span className={`font-mono text-[0.64rem] ${selected ? "text-[#ffe2cd]" : "text-[#af967e]"}`}>{option.count}</span>
              </button>
            );
          })}
        </div>

        <div className="space-y-3.5">
          {visibleOrders.length > 0 ? (
            visibleOrders.map((order) => <OrderCard key={order.id} order={order} onAdvance={() => advanceOrder(order.id)} />)
          ) : (
            <div className="rounded-[1.15rem] border border-dashed border-[#d9c6b2] bg-[#fffaf3] px-6 py-12 text-center">
              <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-[#edf3ed] text-[#54846a]">
                <Check aria-hidden="true" className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-[0.95rem] font-extrabold text-[#383a32]">Nothing here right now</h3>
              <p className="mx-auto mt-1.5 max-w-[17rem] text-[0.75rem] leading-relaxed text-[#907d69]">This part of the queue is clear. New prepaid orders will appear automatically.</p>
              <button type="button" onClick={() => setFilter("all")} className="mt-4 text-[0.75rem] font-extrabold text-[#c6571f]">View all orders</button>
            </div>
          )}
        </div>

        <div className="mt-6 flex items-center justify-center gap-2 text-[0.63rem] font-semibold text-[#a48c76]">
          <span className="grid h-5 w-5 place-items-center rounded-full bg-[#efe1d1]"><RotateCw aria-hidden="true" className="h-3 w-3" /></span>
          Queue updates automatically
          <span className="mx-0.5 h-1 w-1 rounded-full bg-[#d4bca3]" />
          <LockKeyhole aria-hidden="true" className="h-3 w-3" />
          Prepaid orders
        </div>
        <div className="mx-auto mt-4 h-1 w-24 rounded-full bg-[#dfccb7]" />
      </section>
    </main>
  );
}
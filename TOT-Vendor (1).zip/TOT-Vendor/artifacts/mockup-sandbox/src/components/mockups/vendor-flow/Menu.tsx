import { useMemo, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronDown,
  ChevronRight,
  Clock3,
  GripVertical,
  Plus,
  Search,
  SlidersHorizontal,
  Utensils,
  X,
} from "lucide-react";

type MenuItem = {
  id: number;
  name: string;
  description: string;
  price: string;
  prep: string;
  group: "Breakfast" | "Lunch";
  tint: string;
  mark: string;
};

const initialItems: MenuItem[] = [
  {
    id: 1,
    name: "Miso sunrise toast",
    description: "Sourdough · egg · sesame",
    price: "$12.50",
    prep: "8 min",
    group: "Breakfast",
    tint: "#f8c45c",
    mark: "MS",
  },
  {
    id: 2,
    name: "Market shakshuka",
    description: "Baked eggs · tomato · herbs",
    price: "$14.00",
    prep: "14 min",
    group: "Breakfast",
    tint: "#e8754b",
    mark: "SH",
  },
  {
    id: 3,
    name: "Citrus ricotta bowl",
    description: "Ricotta · orange · oat crunch",
    price: "$10.50",
    prep: "5 min",
    group: "Breakfast",
    tint: "#e8a96c",
    mark: "CR",
  },
  {
    id: 4,
    name: "Harissa breakfast roll",
    description: "Potato · harissa · soft egg",
    price: "$11.75",
    prep: "10 min",
    group: "Breakfast",
    tint: "#cf5c43",
    mark: "HR",
  },
  {
    id: 5,
    name: "Charred greens plate",
    description: "Seasonal greens · lemon tahini",
    price: "$13.50",
    prep: "12 min",
    group: "Lunch",
    tint: "#a4aa70",
    mark: "CG",
  },
];

function AvailabilityToggle({
  available,
  onChange,
  itemName,
}: {
  available: boolean;
  onChange: () => void;
  itemName: string;
}) {
  return (
    <button
      type="button"
      aria-pressed={!available}
      aria-label={`${itemName}: ${available ? "mark sold out" : "mark available"}`}
      onClick={(event) => {
        event.stopPropagation();
        onChange();
      }}
      className={`group relative h-7 w-[3.1rem] shrink-0 rounded-full border transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f16d3b] focus-visible:ring-offset-2 ${
        available
          ? "border-[#d6c5b4] bg-[#e8dfd4]"
          : "border-[#f16d3b] bg-[#f16d3b]"
      }`}
    >
      <span
        className={`absolute top-[3px] grid h-5 w-5 place-items-center rounded-full transition-transform duration-200 ${
          available
            ? "left-[3px] bg-[#6f6257] text-transparent"
            : "left-[1.45rem] bg-[#fff8ee] text-[#f16d3b]"
        }`}
      >
        {!available && <Check size={12} strokeWidth={3} aria-hidden="true" />}
      </span>
      <span className="sr-only">
        {available ? "Available" : "Sold out"}
      </span>
    </button>
  );
}

function ItemRow({
  item,
  available,
  onToggle,
  onOpen,
}: {
  item: MenuItem;
  available: boolean;
  onToggle: () => void;
  onOpen: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onOpen}
      className={`group flex w-full items-center gap-3 border-b border-[#eee3d7] px-4 py-3 text-left transition-colors last:border-b-0 hover:bg-[#fffaf3] focus-visible:bg-[#fffaf3] focus-visible:outline-none ${
        !available ? "bg-[#faf3eb]" : "bg-[#fffdf9]"
      }`}
      aria-label={`Open details for ${item.name}`}
    >
      <span
        className="relative grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-[0.95rem] text-[11px] font-bold tracking-[0.08em] text-[#3d2a23]"
        style={{ backgroundColor: item.tint }}
        aria-hidden="true"
      >
        <span className="absolute -right-3 -top-3 h-8 w-8 rounded-full border-[5px] border-[#fff8ee]/45" />
        <span className="absolute -bottom-3 -left-2 h-7 w-7 rounded-full bg-[#fff8ee]/25" />
        <span className="relative">{item.mark}</span>
      </span>
      <span className="min-w-0 flex-1">
        <span
          className={`block truncate text-[14px] font-bold leading-5 tracking-[-0.01em] ${
            available ? "text-[#2d2724]" : "text-[#897d73]"
          }`}
        >
          {item.name}
        </span>
        <span className="mt-0.5 block truncate text-[11px] leading-4 text-[#9a8b7d]">
          {item.description}
        </span>
        <span className="mt-1.5 flex items-center gap-2 text-[10px] font-semibold tracking-[0.02em] text-[#9a8b7d]">
          <span className="text-[#4d4038]">{item.price}</span>
          <span className="h-1 w-1 rounded-full bg-[#d5c4b4]" />
          <Clock3 size={11} strokeWidth={2.2} aria-hidden="true" />
          {item.prep}
          {!available && (
            <span className="ml-0.5 rounded-full bg-[#fbe0d3] px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-[0.08em] text-[#bb4f2d]">
              Sold out
            </span>
          )}
        </span>
      </span>
      <span className="flex shrink-0 items-center gap-2.5">
        <AvailabilityToggle
          available={available}
          onChange={onToggle}
          itemName={item.name}
        />
        <ChevronRight
          size={16}
          strokeWidth={2.2}
          className="text-[#b9a89a] transition-transform duration-200 group-hover:translate-x-0.5"
          aria-hidden="true"
        />
      </span>
    </button>
  );
}

export function Menu() {
  const [items, setItems] = useState(initialItems);
  const [availability, setAvailability] = useState<Record<number, boolean>>({
    1: true,
    2: true,
    3: true,
    4: false,
    5: true,
  });
  const [activeFilter, setActiveFilter] = useState<"All" | "Active" | "Sold out">(
    "All",
  );
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [showAddItem, setShowAddItem] = useState(false);
  const [newName, setNewName] = useState("");
  const [newPrice, setNewPrice] = useState("");

  const breakfastItems = useMemo(
    () => items.filter((item) => item.group === "Breakfast"),
    [items],
  );
  const visibleItems = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return breakfastItems.filter((item) => {
      const matchesSearch =
        !normalized ||
        item.name.toLowerCase().includes(normalized) ||
        item.description.toLowerCase().includes(normalized);
      const isAvailable = availability[item.id];
      const matchesFilter =
        activeFilter === "All" ||
        (activeFilter === "Active" && isAvailable) ||
        (activeFilter === "Sold out" && !isAvailable);
      return matchesSearch && matchesFilter;
    });
  }, [activeFilter, availability, breakfastItems, query]);
  const selectedItem = selectedId
    ? items.find((item) => item.id === selectedId)
    : undefined;
  const activeCount = breakfastItems.filter((item) => availability[item.id]).length;
  const soldOutCount = breakfastItems.length - activeCount;

  const toggleAvailability = (id: number) => {
    setAvailability((current) => ({ ...current, [id]: !current[id] }));
  };

  const addItem = () => {
    const name = newName.trim();
    if (!name) return;
    const id = Math.max(...items.map((item) => item.id), 0) + 1;
    setItems((current) => [
      ...current,
      {
        id,
        name,
        description: "New menu item · add a short description",
        price: newPrice.trim() || "$0.00",
        prep: "10 min",
        group: "Breakfast",
        tint: "#e5b26f",
        mark: name.slice(0, 2).toUpperCase(),
      },
    ]);
    setAvailability((current) => ({ ...current, [id]: true }));
    setNewName("");
    setNewPrice("");
    setShowAddItem(false);
  };

  return (
    <main className="min-h-[100dvh] w-full overflow-x-hidden bg-[#f6f0e8] font-['DM_Sans'] text-[#2d2724]">
      <style>{`
        @keyframes menu-rise { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes menu-sheet { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
        .menu-rise { animation: menu-rise 420ms cubic-bezier(.2,.8,.2,1) both; }
        .menu-sheet { animation: menu-sheet 240ms cubic-bezier(.2,.8,.2,1) both; }
        .menu-scroll::-webkit-scrollbar { display: none; }
        .menu-scroll { scrollbar-width: none; }
      `}</style>

      <section className="relative overflow-hidden bg-[#292421] px-5 pb-5 pt-4 text-[#fff8ee]">
        <div
          className="pointer-events-none absolute -right-12 -top-12 h-40 w-40 rounded-full border-[18px] border-[#f16d3b]/15"
          aria-hidden="true"
        />
        <div
          className="pointer-events-none absolute -bottom-10 left-28 h-20 w-36 -rotate-12 border-t border-[#f6bd6c]/25"
          aria-hidden="true"
        />
        <div className="relative z-10 flex items-center justify-between">
          <button
            type="button"
            aria-label="Back to store overview"
            className="grid h-9 w-9 place-items-center rounded-full border border-[#fff8ee]/15 bg-[#fff8ee]/[0.06] text-[#fff8ee] transition-colors hover:bg-[#fff8ee]/[0.13] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f16d3b]"
          >
            <ArrowLeft size={17} strokeWidth={2.2} />
          </button>
          <span className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#f5b56e]">
            TakeOnTime
          </span>
          <button
            type="button"
            aria-label="Menu settings"
            className="grid h-9 w-9 place-items-center rounded-full border border-[#fff8ee]/15 bg-[#fff8ee]/[0.06] text-[#fff8ee] transition-colors hover:bg-[#fff8ee]/[0.13] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f16d3b]"
          >
            <SlidersHorizontal size={16} strokeWidth={2.1} />
          </button>
        </div>
        <div className="relative z-10 mt-7 menu-rise">
          <p className="mb-1 text-[11px] font-bold uppercase tracking-[0.15em] text-[#f5b56e]">
            Your menu
          </p>
          <h1 className="font-['Fraunces'] text-[34px] font-semibold leading-none tracking-[-0.045em]">
            Keep it moving.
          </h1>
          <p className="mt-2 max-w-[17rem] text-[12px] leading-5 text-[#d7c9bd]">
            A quick check before the next order rush.
          </p>
        </div>
      </section>

      <section className="relative z-20 -mt-1 rounded-t-[1.6rem] bg-[#f6f0e8] px-4 pt-4">
        <div className="flex items-center justify-between">
          <button
            type="button"
            className="flex items-center gap-2 rounded-xl px-1 py-1 text-left transition-colors hover:bg-[#ece2d7] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f16d3b]"
            aria-label="Change menu category, currently Breakfast"
          >
            <span className="grid h-9 w-9 place-items-center rounded-[0.8rem] bg-[#f16d3b] text-[#fff8ee] shadow-[0_5px_14px_rgba(199,76,36,0.22)]">
              <Utensils size={16} strokeWidth={2.1} />
            </span>
            <span>
              <span className="flex items-center gap-1 text-[16px] font-bold leading-5 tracking-[-0.02em]">
                Breakfast <ChevronDown size={15} className="text-[#9a8b7d]" />
              </span>
              <span className="block text-[11px] text-[#9a8b7d]">
                {breakfastItems.length} items · {activeCount} active
              </span>
            </span>
          </button>
          <button
            type="button"
            onClick={() => setShowAddItem(true)}
            className="flex items-center gap-1.5 rounded-full bg-[#2d2724] px-3 py-2 text-[11px] font-bold text-[#fff8ee] shadow-[0_5px_12px_rgba(45,39,36,0.14)] transition-transform hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f16d3b] focus-visible:ring-offset-2"
          >
            <Plus size={14} strokeWidth={2.7} />
            Add item
          </button>
        </div>

        <label className="mt-4 flex h-11 items-center gap-2.5 rounded-xl border border-[#e0d3c5] bg-[#fffaf4] px-3.5 shadow-[0_2px_0_rgba(113,77,49,0.03)] focus-within:border-[#f16d3b] focus-within:ring-2 focus-within:ring-[#f16d3b]/15">
          <Search size={17} className="shrink-0 text-[#a69383]" aria-hidden="true" />
          <span className="sr-only">Search menu items</span>
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search breakfast items"
            className="min-w-0 flex-1 bg-transparent text-[13px] font-medium text-[#2d2724] outline-none placeholder:text-[#aa9a8b]"
          />
          {query && (
            <button
              type="button"
              aria-label="Clear search"
              onClick={() => setQuery("")}
              className="grid h-6 w-6 place-items-center rounded-full text-[#9a8b7d] hover:bg-[#eee3d7] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f16d3b]"
            >
              <X size={14} />
            </button>
          )}
        </label>

        <div className="menu-scroll mt-4 flex gap-2 overflow-x-auto pb-0.5" role="tablist" aria-label="Menu item status">
          {(["All", "Active", "Sold out"] as const).map((filter) => {
            const count =
              filter === "All"
                ? breakfastItems.length
                : filter === "Active"
                  ? activeCount
                  : soldOutCount;
            const isActive = activeFilter === filter;
            return (
              <button
                type="button"
                role="tab"
                aria-selected={isActive}
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`shrink-0 rounded-full border px-3.5 py-2 text-[11px] font-bold transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f16d3b] ${
                  isActive
                    ? "border-[#f16d3b] bg-[#f16d3b] text-[#fff8ee] shadow-[0_4px_10px_rgba(199,76,36,0.18)]"
                    : "border-[#e0d3c5] bg-[#fffaf4] text-[#796c61] hover:border-[#d1b9a7] hover:text-[#2d2724]"
                }`}
              >
                {filter}
                <span className={`ml-1.5 ${isActive ? "text-[#ffe0c2]" : "text-[#ad9b8a]"}`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        <div className="mt-3 overflow-hidden rounded-[1.1rem] border border-[#e9ddcf] bg-[#fffdf9] shadow-[0_7px_20px_rgba(93,61,39,0.05)]">
          <div className="flex items-center justify-between border-b border-[#eee3d7] bg-[#fffaf4] px-4 py-2.5">
            <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#ad9b8a]">
              Items in breakfast
            </span>
            <span className="flex items-center gap-1 text-[10px] font-semibold text-[#b19e8d]">
              <GripVertical size={12} aria-hidden="true" />
              Drag to reorder
            </span>
          </div>
          {visibleItems.length > 0 ? (
            visibleItems.map((item, index) => (
              <div
                key={item.id}
                className="menu-rise"
                style={{ animationDelay: `${index * 45}ms` }}
              >
                <ItemRow
                  item={item}
                  available={availability[item.id]}
                  onToggle={() => toggleAvailability(item.id)}
                  onOpen={() => setSelectedId(item.id)}
                />
              </div>
            ))
          ) : (
            <div className="px-5 py-10 text-center">
              <div className="mx-auto grid h-10 w-10 place-items-center rounded-full bg-[#f8e5d8] text-[#d45e35]">
                <Search size={17} />
              </div>
              <p className="mt-3 text-[13px] font-bold text-[#4a3d35]">No items found</p>
              <p className="mt-1 text-[11px] leading-4 text-[#9a8b7d]">
                Try another search or add a new item.
              </p>
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={() => setShowAddItem(true)}
          className="group mx-auto mt-4 flex items-center gap-2 rounded-full px-3 py-2 text-[11px] font-bold text-[#d45e35] transition-colors hover:bg-[#fbe4d5] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f16d3b]"
        >
          <span className="grid h-5 w-5 place-items-center rounded-full border border-current">
            <Plus size={12} strokeWidth={2.8} />
          </span>
          Add another item
          <ArrowRight size={14} className="transition-transform group-hover:translate-x-0.5" />
        </button>
        <p className="pb-6 pt-2 text-center text-[10px] font-medium text-[#b19e8d]">
          Changes show on your customer menu right away.
        </p>
      </section>

      {selectedItem && (
        <div
          className="fixed inset-0 z-40 flex items-end justify-center bg-[#2d2724]/35 px-3 pb-3 backdrop-blur-[2px]"
          role="presentation"
          onClick={() => setSelectedId(null)}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="item-detail-title"
            className="menu-sheet w-full max-w-[390px] rounded-[1.45rem] bg-[#fffaf4] p-5 shadow-[0_18px_45px_rgba(45,39,36,0.25)]"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="mb-4 flex items-start justify-between">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#d45e35]">
                  Item details
                </p>
                <h2 id="item-detail-title" className="mt-1 font-['Fraunces'] text-[25px] font-semibold tracking-[-0.04em] text-[#2d2724]">
                  {selectedItem.name}
                </h2>
              </div>
              <button
                type="button"
                aria-label="Close item details"
                onClick={() => setSelectedId(null)}
                className="grid h-8 w-8 place-items-center rounded-full bg-[#f0e5d9] text-[#6d5c4f] transition-colors hover:bg-[#e7d8ca] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f16d3b]"
              >
                <X size={16} />
              </button>
            </div>
            <div className="flex items-center justify-between rounded-xl border border-[#eadccc] bg-[#fffdf9] px-3.5 py-3">
              <div>
                <p className="text-[11px] font-bold text-[#4c4037]">Availability</p>
                <p className="mt-0.5 text-[10px] text-[#a18f80]">
                  {availability[selectedItem.id]
                    ? "Customers can order this item"
                    : "Hidden from customer orders"}
                </p>
              </div>
              <AvailabilityToggle
                available={availability[selectedItem.id]}
                onChange={() => toggleAvailability(selectedItem.id)}
                itemName={selectedItem.name}
              />
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <div className="rounded-xl bg-[#f4eadf] px-3.5 py-3">
                <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-[#aa9887]">Price</p>
                <p className="mt-1 text-[16px] font-bold text-[#3b3029]">{selectedItem.price}</p>
              </div>
              <div className="rounded-xl bg-[#f4eadf] px-3.5 py-3">
                <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-[#aa9887]">Prep time</p>
                <p className="mt-1 text-[16px] font-bold text-[#3b3029]">{selectedItem.prep}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setSelectedId(null)}
              className="mt-4 flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-[#2d2724] text-[12px] font-bold text-[#fff8ee] transition-colors hover:bg-[#453832] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f16d3b] focus-visible:ring-offset-2"
            >
              Edit full item
              <ArrowRight size={15} />
            </button>
          </section>
        </div>
      )}

      {showAddItem && (
        <div
          className="fixed inset-0 z-40 flex items-end justify-center bg-[#2d2724]/35 px-3 pb-3 backdrop-blur-[2px]"
          role="presentation"
          onClick={() => setShowAddItem(false)}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="add-item-title"
            className="menu-sheet w-full max-w-[390px] rounded-[1.45rem] bg-[#fffaf4] p-5 shadow-[0_18px_45px_rgba(45,39,36,0.25)]"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#d45e35]">
                  Breakfast
                </p>
                <h2 id="add-item-title" className="mt-1 font-['Fraunces'] text-[25px] font-semibold tracking-[-0.04em] text-[#2d2724]">
                  Add an item
                </h2>
              </div>
              <button
                type="button"
                aria-label="Close add item form"
                onClick={() => setShowAddItem(false)}
                className="grid h-8 w-8 place-items-center rounded-full bg-[#f0e5d9] text-[#6d5c4f] transition-colors hover:bg-[#e7d8ca] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f16d3b]"
              >
                <X size={16} />
              </button>
            </div>
            <label className="mt-5 block text-[11px] font-bold text-[#5d4d42]">
              Item name
              <input
                autoFocus
                value={newName}
                onChange={(event) => setNewName(event.target.value)}
                placeholder="e.g. Za’atar egg plate"
                className="mt-1.5 h-11 w-full rounded-xl border border-[#e0d3c5] bg-[#fffdf9] px-3.5 text-[13px] font-medium text-[#2d2724] outline-none placeholder:text-[#b19e8d] focus:border-[#f16d3b] focus:ring-2 focus:ring-[#f16d3b]/15"
              />
            </label>
            <label className="mt-3 block text-[11px] font-bold text-[#5d4d42]">
              Price
              <input
                inputMode="decimal"
                value={newPrice}
                onChange={(event) => setNewPrice(event.target.value)}
                placeholder="$0.00"
                className="mt-1.5 h-11 w-full rounded-xl border border-[#e0d3c5] bg-[#fffdf9] px-3.5 text-[13px] font-medium text-[#2d2724] outline-none placeholder:text-[#b19e8d] focus:border-[#f16d3b] focus:ring-2 focus:ring-[#f16d3b]/15"
              />
            </label>
            <div className="mt-4 flex gap-2">
              <button
                type="button"
                onClick={() => setShowAddItem(false)}
                className="h-11 flex-1 rounded-xl border border-[#e0d3c5] text-[12px] font-bold text-[#796c61] transition-colors hover:bg-[#f4eadf] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f16d3b]"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={!newName.trim()}
                onClick={addItem}
                className="h-11 flex-1 rounded-xl bg-[#f16d3b] text-[12px] font-bold text-[#fff8ee] transition-all hover:bg-[#dd5d31] disabled:cursor-not-allowed disabled:opacity-45 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f16d3b] focus-visible:ring-offset-2"
              >
                Add to menu
              </button>
            </div>
          </section>
        </div>
      )}
    </main>
  );
}